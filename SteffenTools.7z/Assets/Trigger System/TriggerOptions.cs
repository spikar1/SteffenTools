﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace TriggerSystem {
    [CreateAssetMenu()]
    public class TriggerOptions : ScriptableObject {
        private static TriggerOptions instance;

        private void OnEnable() {

        }

    }

}