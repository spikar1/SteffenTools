﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace TriggerSystem2D {
    public class TriggerOptions2D : ScriptableObject {

        public int myInt;

        public Vector2 connectorGravity;
    }

}